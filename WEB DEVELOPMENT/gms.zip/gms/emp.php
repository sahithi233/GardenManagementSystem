<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="styles.css">
  <title>Admin Dashboard</title>
  <style >
    /* Reset default margin and padding */
body, h1, h2, h3, ul, li, p {
  margin: 0;
  padding: 0;
}

body {
  font-family: Arial, sans-serif;
}

header {
  background-color: #E0C2B2;
  color: #fff;
  padding: 10px;
  display: flex;
}
h1{
  padding-left: 10px;
}
nav ul {
  list-style: none;
  text-align: right;
  background-color: #f0f0f0;
  padding: 10px;
}

nav li {
  margin-right: 20px;
  text-align: center;
  display: inline-block;
}

nav a {
  text-decoration: none;
  color: #333;
  font-weight: bold;
}

section {
            margin-bottom: 30px;
            padding: 20px;
            border: 1px solid #ddd;
            background-color: white;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
section h2{
  text-align: center;
}
/* ... Your existing CSS styles ... */

.employee-table {
  margin-top: 20px;
}

table {
  width: 100%;
  border-collapse: collapse;
}

table, th, td {
  border: 1px solid #ccc;
}

th, td {
  padding: 10px;
  text-align: left;
}

th {
  background-color: #f0f0f0;
}
 .highlight {
            background-color: #f0f0f0 ;
            font-weight: bold;
        }

a{
  text-decoration: none;
  color: white;
}
/* Style for the search bar */
.search-bar {
  width: 100%;
    position: relative;
    display: flex;
    align-items: center;
}

/* Style for the search icon */
.search-icon {
    font-size: 20px; /* Adjust the size of the search icon */
    margin-right: 10px; /* Adjust the spacing between the icon and input */
    color: #333; /* Icon color */
}

/* Style for the search input */
.search-input {
    padding: 10px; /* Adjust the padding inside the input */
    border: 1px solid #ccc; /* Border color */
    border-radius: 5px; /* Rounded corners */
    font-size: 16px; /* Adjust the font size */
    width: 200px; /* Adjust the width of the input */
    outline: none; /* Remove the outline when focused */
}

/* Style for the placeholder text inside the input */
.search-input::placeholder {
    color: #999; /* Placeholder text color */
}


 .highlight {
            background-color: #f0f0f0 ;
            font-weight: bold;
        }

  </style>

</head>
<body>
  <header>
    <img src="growise.jpg" height="30px" width="40px">
    <h1><a href="adashboard.php">GROWISE</a></h1>
  </header>
  <nav>
    <ul>
      <li><a href="addemp.php" style="text-decoration:none;">ADD USERS</a></li>
      <li><a href="profile.php" style="text-decoration:none;">PROFILE</a></li>
      <li><a href="logout.php" style="text-decoration:none;">LOG OUT</a></li>
    </ul>
  </nav>

 <div class="search-bar">
    <span class="search-icon">&#128269;</span>
    <input type="text" name="search" id="search-input" class="search-input" placeholder="Search..." oninput="performSearch()">
  </div>
<div class="employee-table">
    <br>
    <div id="table-container"> <!-- Wrap the table within a container div -->
      <table>
        <thead>
          <tr>
            <th>Sl.No</th>
            <th>Name</th>
            <th>Role</th>
            <th>Mob.No</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody id="search-results">
      <?php
$conn = mysqli_connect("localhost", "root", "", "gms");

$search = isset($_POST['search']) ? $_POST['search'] : '';
$sql = "SELECT * FROM USER WHERE name LIKE ? OR role LIKE ? OR mobile_no LIKE ?";
$stmt = mysqli_prepare($conn, $sql);

// Add '%' around the search term for a partial match
$searchTerm = '%' . $search . '%';
mysqli_stmt_bind_param($stmt, "sss", $searchTerm, $searchTerm, $searchTerm);
mysqli_stmt_execute($stmt);

$data = mysqli_stmt_get_result($stmt);
$s_id = 1;

while ($row = mysqli_fetch_assoc($data)) {
  echo "<tr>";
  echo "<td>" . $s_id . "</td>";
  echo "<td>" . $row['name'] . "</td>";
  echo "<td>" . $row['role'] . "</td>";
  echo "<td>" . $row['mobile_no'] . "</td>";
  $s_id++;
  $status = $row['status'];

  if ($status === 'Active') {
    echo "<td>";
    echo "<form method='POST' class='status-form'>";
    echo "<input type='hidden' name='user_id' value='" . $row['id'] . "'>";
    echo "<input type='hidden' name='action' value='Deactive'>";
    echo "<input type='submit' value='Deactivate'>";
    echo "</form>";
    echo "</td>";
  } else {
    echo "<td>";
    echo "<form method='POST' class='status-form'>";
    echo "<input type='hidden' name='user_id' value='" . $row['id'] . "'>";
    echo "<input type='hidden' name='action' value='Active'>";
    echo "<input type='submit' value='Activate'>";
    echo "</form>";
    echo "</td>";
  }

  echo "</tr>";
}

// Process the form submission to update the status
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['user_id']) && isset($_POST['action'])) {
  $userId = $_POST['user_id'];
  $action = $_POST['action'];

  // Perform the status update based on the submitted form data
  $updateQuery = "UPDATE user SET status = ? WHERE id = ?";
  $stmt = mysqli_prepare($conn, $updateQuery);
  mysqli_stmt_bind_param($stmt, "si", $action, $userId);
  $result = mysqli_stmt_execute($stmt);

  // Check if the update was successful
  if ($result) {
    echo "Status updated successfully";
  } else {
    echo 'Failed to update status: ' . mysqli_error($conn);
  }

  // Stop further execution
  exit();
}
?>


        </tbody>
      </table>
    </div>
  </div>

  <!-- Add this script in your HTML file -->
<script>
  document.addEventListener("DOMContentLoaded", function () {
    const searchInput = document.getElementById("search-input");
    const contentRows = document.querySelectorAll("#search-results tr");

    searchInput.addEventListener("input", function () {
      const query = searchInput.value.toLowerCase();

      // Loop through content rows and show/hide based on the search input
      contentRows.forEach((row) => {
        const itemText = row.textContent.toLowerCase();
        if (itemText.includes(query)) {
          row.style.display = ""; // Show the row
        } else {
          row.style.display = "none"; // Hide the row
        }
      });
    });
  });
</script>


</body>
</html>
