<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="styles.css">
  <title>gms</title>
  <style >
    /* Reset default margin and padding */
body, h1, h2, h3, ul, li, p {
  margin: 0;
  padding: 0;
}

body {
  font-family: Arial, sans-serif;
}

header {
  background-color: #E0C2B2;
  color: #fff;
  padding: 10px;
  display: flex;
}
h1{
  padding-left: 10px;
}
nav ul {
  list-style: none;
  text-align: right;
  background-color: #f0f0f0;
  padding: 10px;
}

nav li {
  margin-right: 20px;
  text-align: center;
  display: inline-block;
}
a{
  text-decoration: none;
  color: white;
}
nav a {
  text-decoration: none;
  color: #333;
  font-weight: bold;
}

table {
  width: 80%;
  border-collapse: collapse;
  text-align: center;
}

table, th, td {
  border: 1px solid #ccc;
}

th, td {
  padding: 10px;
  text-align: left;
}

th {
  background-color: #f0f0f0;
}
  </style>
</head>
<body>
  <header>
    <img src="growise.jpg" height="30px" width="40px">
    <h1><a href="mdashboard.php"style="text-decoration:none;">GROWISE</h1>
  </header>
  <nav>
    <ul>
      
      <li><a href="mbell.php"><img src="bell.svg"></a></li>
      <li><a href="jobs.php">Jobs</a></li>
      <li><a href="profile.php">Profile</a></li>
      <li><a href="logout.php">Logout</a></li>
    </ul>
  </nav>
<center>


 <?php
// Establish a database connection
    $conn = mysqli_connect("localhost", "root","","gms");

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// SQL query to retrieve the leaderboard data
$sql = "SELECT name,rating FROM user where role ='Supervisor' ORDER BY rating DESC LIMIT 3" ; // Change the table name and criteria as needed
$result = mysqli_query($conn, $sql);

// Check if there are results
if (mysqli_num_rows($result) > 0) {
    echo "<h1>Supervisor Leaderboard</h1>";
    echo "<table>";
    echo "<tr><th>Rank</th><th>Employee</th><th>week</th><th>week</th><th>week</th><th>week</th></tr>";

    $rank = 1;
    while ($row = mysqli_fetch_assoc($result)) {
        echo "<tr>";
        echo "<td>" . $rank++ . "</td>";
        echo "<td>" . $row['name'] . "</td>";
        echo "<td>" . $row['rating'] . "</td>";
        echo "<td>" . $row['rating'] . "</td>";
         echo "<td>" . $row['rating'] . "</td>";
          echo "<td>" . $row['rating'] . "</td>";
        echo "</tr>";
    }

    echo "</table>";
} else {
    echo "No leaderboard data available.";
}

mysqli_close($conn); // Close the database connection
?>
</center>
</body>
</html>
